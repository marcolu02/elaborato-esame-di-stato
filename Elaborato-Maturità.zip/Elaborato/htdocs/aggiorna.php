<?php
    ini_set('session.gc_maxlifetime', 600);
    session_set_cookie_params(600);
    session_start();
    $now = time();
    if (isset($_SESSION['discard_after']) && $now > $_SESSION['discard_after']) {
        session_unset();
        session_destroy();
        session_start();
    }

    $_SESSION['discard_after'] = $now + 600;

    $servername = "localhost";
    $username="marco";
    $password="marco";
    $db="pontecert";

    $conn=mysqli_connect($servername, $username, $password, $db);

    if(!$conn)
    {
        die("Connection Failed; ".mysqli_connect_error());
    }



    if($_SESSION["Active"]==true){
        $usr=$_SESSION["Username"];
    
    }  
    else
    {
        header("location: login.html");
    }

    $strSQL="select * from valori_orari where valore_medio>0.50 and ora_rilevamento>(select max(data_ora_rilevazione) from valori_critici)";

    $result=mysqli_query($conn, $strSQL);
   
   
    if(mysqli_num_rows($result) != 0)
    {
           
        while($row=mysqli_fetch_array($result))
        {    
               
               
            $strSQL="insert into valori_critici (valore, data_ora_Rilevazione, data_valore, id_Sensore) values ($row[1], '$row[2]', '$row[3]', $row[4]);";
            if(mysqli_query($conn, $strSQL))
                 echo"Valore aggiunto";
            else
                echo"Valore non aggiunto";
           
        }
        echo ("<script LANGUAGE='JavaScript'>
        window.alert('Aggiornamento Riuscito.');
        window.location.href='valori_critici.php';
        </script>");
    }
    else{
        echo ("<script LANGUAGE='JavaScript'>
        window.alert('Nessun Nuovo Dato Critico.');
        window.location.href='valori_critici.php';
        </script>");
    }

?>