<?php
    ini_set('session.gc_maxlifetime', 600);
    session_set_cookie_params(600);
    session_start();
    $now = time();
    if (isset($_SESSION['discard_after']) && $now > $_SESSION['discard_after']) {
        session_unset();
        session_destroy();
        session_start();
    }
        if($_SESSION["Active"]==true){
        $usr=$_SESSION["Username"];   
    }  
    else
    {
        header("location: login.html");
    }

    $_session["Active"]=false;
    $hostname="localhost";
    $username="marco";
    $password="marco";
    $conn=mysqli_connect($hostname, $username, $password, $db);
    if(!$conn)
    {
        die("Connessione al Portale Fallito; ".mysqli_connect_error());
    }
    echo"Connessione avvenuta correttamente";

    $db1=mysqli_select_db($conn, "pontecert");
    if(!$db1)
    {
        die('Accesso al database non riuscito'.mysqli_error($conn));
    }
    echo"Accesso al database effettuato con successo"."<br>";

    $id=$_POST["id"];
    $mo=$_POST["modi"];
    $modifica=$_POST["mod"];
    echo"$id,$mo,$modifica";
    if($mo==0){
        $strSQL="UPDATE `ponti` SET `Regione` = '$modifica' WHERE `ponti`.`ID_Ponte` = $id;";  
    }
    if($mo==1){
        $strSQL="UPDATE `ponti` SET `citta` = '$modifica' WHERE `ponti`.`ID_Ponte` = $id;";
    }
    if($mo==2){
        $strSQL="UPDATE `ponti` SET `indirizzo` = '$modifica' WHERE `ponti`.`ID_Ponte` = $id;";
    }
    if($mo==3){
        $strSQL="UPDATE `ponti` SET `lunghezza` = $modifica WHERE `ponti`.`ID_Ponte` = $id;";
    }
    if($mo==4){
        $strSQL="UPDATE `ponti` SET `anno_costruzione` = $modifica WHERE `ponti`.`ID_Ponte` = $id;";
    }
    if($mo==5){
        $strSQL="UPDATE `ponti` SET `N_piloni` = $modifica WHERE `ponti`.`ID_Ponte` = $id;";
    }

    if(mysqli_query($conn, $strSQL))
    {
        echo ("<script LANGUAGE='JavaScript'>
        window.alert('Dati Correttamente Modificati.');
        window.location.href='modificap.php';
        </script>");
    }
  
    else{
        echo ("<script LANGUAGE='JavaScript'>
        window.alert('Errore nella modifica dei dati. Ricontrolla i tuoi dati.');
        window.location.href='modificap.php';
        </script>");
    }

?>