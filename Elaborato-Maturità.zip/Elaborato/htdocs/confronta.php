<?php
    ini_set('session.gc_maxlifetime', 600);
    session_set_cookie_params(600);
    session_start();
    $now = time();
    if (isset($_SESSION['discard_after']) && $now > $_SESSION['discard_after']) {
        session_unset();
        session_destroy();
        session_start();
    }

    $_SESSION['discard_after'] = $now + 600;
    $servername = "localhost";
    $username="marco";
    $password="marco";
    $db="pontecert";

    $conn=mysqli_connect($servername, $username, $password, $db);

    if(!$conn)
    {
        die("Connection Failed; ".mysqli_connect_error());
    }



    if($_SESSION["Active"]==true){
        $usr=$_SESSION["Username"];
    
    }  
    else
    {
        header("location: login.html");
    }

    $cods=$_SESSION["cods"];
    $anno1=$_POST["anno1"];
    $anno2=$_POST["anno2"];
    if($anno1==0)
    {
        $anno1=2019;
    }  
    if($anno2==0)
    {
        $anno2=2020;
    }
?>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width">
        <title>Confronto Anni</title>
        <link href="style.css" rel="stylesheet" type="text/css" />
        <link rel="shortcut icon" href="icona.ico" style="border-radius:20px 20px 20px 20px" />
        
        <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
        <script type='text/javascript'>
            google.charts.load('current', {'packages':['annotationchart']});
            google.charts.setOnLoadCallback(drawChart);
      
            function drawChart() {
                var data = new google.visualization.DataTable();
                data.addColumn('date', 'Date');
                data.addColumn('number', 'Sensore: <?php echo"$cods"?> Anno: <?php echo"$anno1"?>');
                data.addColumn('number', 'Sensore: <?php echo"$cods"?> Anno: <?php echo"$anno2"?>');
                data.addRows([
                <?php
                    
                    $strSQL="select * ";
                    $strSQL.="from valori_orari where ID_sensore=$cods and Data_valore between '$anno1-1-1' and '$anno1-12-31';";
                    $risultato1=mysqli_query($conn, $strSQL);
                    $strSQL="select * ";
                    $strSQL.="from valori_orari where ID_sensore=$cods and Data_valore between '$anno2-1-1' and '$anno2-12-31';";
                    $risultato2=mysqli_query($conn, $strSQL);
                    
                    if(mysqli_num_rows($risultato1) != 0 and mysqli_num_rows($risultato2) != 0)
                    { 
                        while($d1=mysqli_fetch_array($risultato1) and $d2=mysqli_fetch_array($risultato2))
                        {   
                            $data=$d1[3];
                            $m=date("m",strtotime($data));
                            $d=date("d",strtotime($data));
                            echo "[new Date($anno1, $m-1, $d), $d1[1],$d2[1]],";    
                        }
                        echo "]);";
                    }   
                ?>
                var chart = new google.visualization.AnnotationChart(document.getElementById('chart_div'));
                var options = {
                    displayAnnotations: true
                };
                chart.draw(data, options);
            }
        </script>
    
    </head>
    <body>    
    <div style="text-align:center; height: 70px; background-color:white; border-bottom: 2px solid;"><h1 style="color: orange; padding-top: 17px">Portale PonteCert</h1>
    </div>
    <div class="hed" style="background-color: white">
        <div class="men1" style="padding-left: 20px"> 
            <script type="text/javascript"> var css_file=document.createElement("link"); css_file.setAttribute("rel","stylesheet"); css_file.setAttribute("type","text/css"); css_file.setAttribute("href","//s.bookcdn.com//css/cl/bw-cl-c22.css?v=0.0.1"); document.getElementsByTagName("head")[0].appendChild(css_file); </script> <div id="tw_22_1387727297"><div style="width:200px; height:px; margin: 0 auto;"><a href="https://hotelmix.it/time/rome-18087">Roma</a><br/></div></div> <script type="text/javascript"> function setWidgetData_1387727297(data){ if(typeof(data) != 'undefined' && data.results.length > 0) { for(var i = 0; i < data.results.length; ++i) { var objMainBlock = ''; var params = data.results[i]; objMainBlock = document.getElementById('tw_'+params.widget_type+'_'+params.widget_id); if(objMainBlock !== null) objMainBlock.innerHTML = params.html_code; } } } var clock_timer_1387727297 = -1; widgetSrc = "https://widgets.booked.net/time/info?ver=2;domid=609;type=22;id=1387727297;scode=124;city_id=18087;wlangid=5;mode=0;details=0;background=ffffff;border_color=ffffff;color=686868;add_background=ffffff;add_color=333333;head_color=ffffff;border=0;transparent=0"; var widgetUrl = location.href; widgetSrc += '&ref=' + widgetUrl; var wstrackId = "421968434"; if (wstrackId) { widgetSrc += ';wstrackId=' + wstrackId + ';' } var timeBookedScript = document.createElement("script"); timeBookedScript.setAttribute("type", "text/javascript"); timeBookedScript.src = widgetSrc; document.body.appendChild(timeBookedScript); </script>
        </div>
        <div class="men" style="text-align: center">
            <form action="">
                <input type="button" value="Ricerca Con Mappa" style="margin:30px; background-color: orange; font-size:medium; width: 170px; height: 30px; Color: white;" onclick="location.href='rmappa.php'">
                <input type="button" value="Visualizza Ponti" style="margin:30px; background-color: orange; font-size:medium; width: 170px; height: 30px; Color: white;" onclick="location.href='ponti.php'">
                <input type="button"  value="Valori Critici" style="margin:30px; background-color: orange; font-size:medium; width: 160px; height: 30px; color: white" onclick="location.href='valori_critici.php'">
                <input type="button"  value="Modifica Dati Ponte" style="margin:30px; background-color: orange; font-size:medium; width: 160px; height: 30px; color: white" onclick="location.href='modificap.php'">   
                </form>
        </div>
        <div class="men1" style="text-align: right;">
            <input type="button"  value="LogOut" style="margin-right:20px; margin-top: 32px;background-color: red; color: white; width: 100px;font-size:medium; height: 30px" onclick="location.href='logout.php'">
        </div>
    </div>
    <div style="background-color: white">
        <h1 style="text-align: center; background-color: white;">Valore Sensore</h1><br>
        <form action='mediasensored.php' method="POST">
            <label>Ricerca per data: </label>
            <input type="date" name="datar" >
            <input type="Submit" value="Ricerca" name="ricerca" style="border-radius: 5px 5px 5px 5px; height: 30px; font-size: 15px; background-color: darkorange; margin-left: 30px" >
        </form>
        <form action='confronta.php' method="POST">
            <label>Confronta Anni: </label>
            <select name="anno1" id="" style="background-color: gainsboro" placeholder="Anno">
                    <option value="0">2019</option>
            </select>
            <select name="anno2" id="" style="background-color: gainsboro" placeholder="Anno">
                    <option value="0">2020</option>
            </select>
            <input type="Submit" value="Confronta" name="confronta" style="border-radius: 5px 5px 5px 5px; height: 30px; font-size: 15px; background-color: darkorange; margin-left: 30px" >
        </form>
        <div>
            <?php 
                echo"<h3>Confronto Anno $anno1 e $anno2</h3>";
            ?>
            <div id='chart_div' style='margin-left: 2.5%;width: 95%; height: 450px;'></div>
        </div>
        <br>
    </div>
    </body>
</html>