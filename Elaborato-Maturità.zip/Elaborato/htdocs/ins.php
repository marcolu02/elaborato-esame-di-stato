<?php
    ini_set('session.gc_maxlifetime', 600);
    session_set_cookie_params(600);
    session_start();
    $now = time();
    if (isset($_SESSION['discard_after']) && $now > $_SESSION['discard_after']) {
         session_unset();
        session_destroy();
        session_start();
    }
    if($_SESSION["Active"]==true){
        $usr=$_SESSION["Username"];   
    }  
    else
    {
        header("location: login.html");
    }

    $_session["Active"]=false;
    $hostname="localhost";
    $username="marco";
    $password="marco";

    $conn=mysqli_connect($hostname, $username, $password, $db);

    if(!$conn)
    {
        die("Connessione al Portale Fallito; ".mysqli_connect_error());
    }
        echo"Connessione avvenuta correttamente";

    $db1=mysqli_select_db($conn, "pontecert");
    if(!$db1)
    {
        die('Accesso al database non riuscito'.mysqli_error($conn));
    }
    echo"Accesso al database effettuato con successo"."<br>";

    $d=1;
    while($d<32)
    {
        $r=rand(25,35)/100;
        $strSQL="INSERT INTO `valori_orari` (`ID_Rilevamento_Orario`, `Valore_Medio`, `Ora_Rilevamento`, `Data_Valore`, `ID_Sensore`) VALUES (NULL, $r , '2020-12-$d 00:00:00.000000', '2020-12-$d', 1);";
        if(mysqli_query($conn, $strSQL))
        {
            echo ("modifica avvenuta<br>");
     
        }
        else{
            echo ("<script LANGUAGE='JavaScript'>
            window.alert('Errore nella modifica dei dati. Ricontrolla i tuoi dati.');
            </script>");
        }
        $d=$d+1;
    }
?>