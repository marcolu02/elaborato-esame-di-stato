<?php
    ini_set('session.gc_maxlifetime', 600);
    session_set_cookie_params(600);
    session_start();
    $now = time();
    if (isset($_SESSION['discard_after']) && $now > $_SESSION['discard_after']) {
        session_unset();
        session_destroy();
        session_start();
    }
    $_SESSION['discard_after'] = $now + 600;
    $_session["Active"]=false;
    $hostname="localhost";
    $username="marco";
    $password="marco";
    $db="Credenziali_Pontecert";
    $conn=mysqli_connect($hostname, $username, $password, $db);
    if(!$conn)
    {
        die("Connessione al Portale Fallito; ".mysqli_connect_error());
    }
    echo"Connessione avvenuta correttamente";
    $usr=$_POST["user"];
    $pas=$_POST["pass"];
    $sql = "Select * from accesso where codice_utente='$usr' and pass='$pas'";
    $results = mysqli_query($conn, $sql);
    if(mysqli_num_rows($results) > 0)
    {  
        $_SESSION["Active"]=true;
        $_SESSION["Username"]= $usr;
        header("location: index.php");
    }
    else{
        header("location: login1.html");
    }
    mysqli_close($conn);
?>