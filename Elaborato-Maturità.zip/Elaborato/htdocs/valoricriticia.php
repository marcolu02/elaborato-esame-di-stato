<?php
    ini_set('session.gc_maxlifetime', 600);
    session_set_cookie_params(600);
    session_start();
    $now = time();
    if (isset($_SESSION['discard_after']) && $now > $_SESSION['discard_after']) {
        session_unset();
        session_destroy();
        session_start();
    }
    $_SESSION['discard_after'] = $now + 600;
    $servername = "localhost";
    $username="marco";
    $password="marco";
    $db="pontecert";

    $conn=mysqli_connect($servername, $username, $password, $db);

    if(!$conn)
    {
        die("Connection Failed; ".mysqli_connect_error());
    }
    if($_SESSION["Active"]==true){
        $usr=$_SESSION["Username"];
    
    }  
    else
    {
        header("location: login.html");
    }

    $anno=$_POST["anno"];
    if($anno==0)
    {
        $anno=2019;
    }
    if($anno==1)
    {
        $anno=2020;
    }
    if($anno==2)
    {
        $anno=2021;
    }

?>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width">
        <title>Valore Sensore</title>
        <link href="style.css" rel="stylesheet" type="text/css" />
        <link rel="shortcut icon" href="icona.ico" style="border-radius:20px 20px 20px 20px" />
    </head>
    <body>
        <div style="text-align:center; height: 70px; background-color:white; border-bottom: 2px solid;"><h1 style="color: orange; padding-top: 17px">Portale PonteCert</h1>
        </div>
        <div class="hed" style="background-color: white">
            <div class="men1" style="padding-left: 20px">
                <script type="text/javascript"> var css_file=document.createElement("link"); css_file.setAttribute("rel","stylesheet"); css_file.setAttribute("type","text/css"); css_file.setAttribute("href","//s.bookcdn.com//css/cl/bw-cl-c22.css?v=0.0.1"); document.getElementsByTagName("head")[0].appendChild(css_file); </script> <div id="tw_22_1387727297"><div style="width:200px; height:px; margin: 0 auto;"><a href="https://hotelmix.it/time/rome-18087">Roma</a><br/></div></div> <script type="text/javascript"> function setWidgetData_1387727297(data){ if(typeof(data) != 'undefined' && data.results.length > 0) { for(var i = 0; i < data.results.length; ++i) { var objMainBlock = ''; var params = data.results[i]; objMainBlock = document.getElementById('tw_'+params.widget_type+'_'+params.widget_id); if(objMainBlock !== null) objMainBlock.innerHTML = params.html_code; } } } var clock_timer_1387727297 = -1; widgetSrc = "https://widgets.booked.net/time/info?ver=2;domid=609;type=22;id=1387727297;scode=124;city_id=18087;wlangid=5;mode=0;details=0;background=ffffff;border_color=ffffff;color=686868;add_background=ffffff;add_color=333333;head_color=ffffff;border=0;transparent=0"; var widgetUrl = location.href; widgetSrc += '&ref=' + widgetUrl; var wstrackId = "421968434"; if (wstrackId) { widgetSrc += ';wstrackId=' + wstrackId + ';' } var timeBookedScript = document.createElement("script"); timeBookedScript.setAttribute("type", "text/javascript"); timeBookedScript.src = widgetSrc; document.body.appendChild(timeBookedScript); </script>
            </div>
            <div class="men" style="text-align: center">
                <form action="">
                    <input type="button" value="Ricerca Con Mappa" style="margin:30px; background-color: orange; font-size:medium; width: 170px; height: 30px; Color: white;" onclick="location.href='rmappa.php'">
                    <input type="button" value="Visualizza Ponti" style="margin:30px; background-color: orange; font-size:medium; width: 170px; height: 30px; Color: white;" onclick="location.href='ponti.php'">
                    <input type="button"  value="Valori Critici" style="margin:30px; background-color: orange; font-size:medium; width: 160px; height: 30px; color: white" onclick="location.href='valori_critici.php'">
                    <input type="button"  value="Modifica Dati Ponte" style="margin:30px; background-color: orange; font-size:medium; width: 160px; height: 30px; color: white" onclick="location.href='modificap.php'">
                </form>
            </div>
            <div class="men1" style="text-align: right;">
                <input type="button"  value="LogOut" style="margin-right:20px; margin-top: 32px;background-color: red; color: white; width: 100px;font-size:medium; height: 30px" onclick="location.href='logout.php'">
            </div>
        </div>
        <div style="background-color: white">
            <h1 style="text-align: center; background-color: white;">Ricerca Criticità Annuali</h1><br>
            <input type="button" value="Aggiorna Dati" name="aggiorna" style="border-radius: 5px 5px 5px 5px; height: 30px; font-size: 15px; background-color: darkorange; margin-left: 2px" onclick="location.href='aggiorna.php'">
            <input type="button" value="Dettagli" name="aggiorna" style="border-radius: 5px 5px 5px 5px; height: 30px; font-size: 15px; background-color: darkorange; margin-left: 2px" onclick="location.href='dettaglic.php?anno=<?php echo($anno) ?>'"><br><br>
            <form action='valoricriticia.php' method="POST">
                <label>Valori Annuali: </label>
                <select name="anno" id="" style="background-color: gainsboro" placeholder="Anno">
                    <option value="0">2019</option>
                    <option value="1">2020</option>
                    <option value="2">2021</option>
                </select>
            <input type="submit" value="Visualizza" name="confronta" style="border-radius: 5px 5px 5px 5px; height: 30px; font-size: 15px; background-color: darkorange; margin-left: 30px" >
            </form>
            <div>
                <?php
                    echo"<h2>Anno: $anno </h2>";
                    $strSQL="select sensori.ID_centralina, count(*) from valori_critici,sensori where valori_critici.Data_valore between '$anno-1-1' and '$anno-12-31' and sensori.id_sensore=valori_critici.ID_Sensore group by sensori.ID_Centralina";
                    $result=mysqli_query($conn, $strSQL);
                    if(mysqli_num_rows($result) != 0)
                    {
                        echo "<br><table border=5 cellspacing=0>";
                        echo "<tr>";
                        echo "<th> ID Centralina </th>";
                        echo "<th> Numero Valori Critici </th>";
                        echo "<tr>";
                        while($row=mysqli_fetch_array($result))
                        {
                            echo "<tr>";
                            echo"<td> $row[0] </td>";
                            echo"<td> $row[1] </td>";
                            echo "<tr>";
                        }
                        echo"</table>";
                    }
                    else
                        echo "<h2>Non sono presenti centraline con valori critici per l'anno: $anno.</h2><br>";
                ?>
                <br>
                </b>
                <div id='chart_div' style='width: 900px; height: 400px;'></div>
                <br><br>
            </div>
        </div>
    </body>
</html>